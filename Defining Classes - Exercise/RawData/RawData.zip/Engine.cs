﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RawData
{
    public class Engine
    {
        public int EngineSpeed { get; set; }
        public int EnginePower { get; set; }
    }
}
